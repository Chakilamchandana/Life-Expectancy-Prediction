# project-schakil-ltaduru
B565- Final Project
This repository contains the jupyter notebook, dataset used in the project, slides for the mini-presentation, and the final report as required by the course requirement. 
